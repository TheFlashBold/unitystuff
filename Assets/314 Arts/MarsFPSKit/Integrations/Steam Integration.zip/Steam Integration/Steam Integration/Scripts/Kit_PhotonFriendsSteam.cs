﻿using UnityEngine;
using System.Collections.Generic;
using System.Linq;

using Steamworks;

namespace MarsFPSKit
{
    namespace PhotonFriends
    {
        /// <summary>
        /// This implements Photon Friends using PlayerPrefs.
        /// </summary>
        [CreateAssetMenu(menuName = "MarsFPSKit/Photon Friends/Steam")]
        public class Kit_PhotonFriendsSteam : Kit_PhotonFriendsBase
        {
            public override void AddFriend(Kit_MainMenu mainMenu, string friendToAdd)
            {
                //Unused
            }

            public override void LoggedIn(Kit_MainMenu mainMenu)
            {
                //Load
                Load();
            }

            public override void OnUpdatedFriendList(Kit_MainMenu mainMenu)
            {
                //Redraw
                if (mainMenu.photonFriendsUI)
                {
                    mainMenu.photonFriendsUI.Redraw();
                }
            }

            public override void RefreshFriendsList(Kit_MainMenu mainMenu)
            {
                List<string> myFriends = new List<string>();

                int friendCount = SteamFriends.GetFriendCount(EFriendFlags.k_EFriendFlagImmediate);
                for (int i = 0; i < friendCount; ++i)
                {
                    CSteamID friendSteamId = SteamFriends.GetFriendByIndex(i, EFriendFlags.k_EFriendFlagImmediate);
                    string friendName = SteamFriends.GetFriendPersonaName(friendSteamId);
                    myFriends.Add(friendName);
                }

                //Request new friends
                PhotonNetwork.FindFriends(myFriends.ToArray());
            }

            public override void RemoveFriend(Kit_MainMenu mainMenu, string friendToRemove)
            {
                //Unused
            }

            /// <summary>
            /// Loads friends from the Player Prefs
            /// </summary>
            void Load()
            {
                //Unused
            }

            /// <summary>
            /// Saves friends to the Player Prefs
            /// </summary>
            void Save()
            {
                //Unused
            }
        }
    }
}
