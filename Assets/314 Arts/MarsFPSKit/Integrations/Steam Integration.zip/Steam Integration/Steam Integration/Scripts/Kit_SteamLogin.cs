﻿using UnityEngine;
using Steamworks;

namespace MarsFPSKit
{
    namespace SteamIntegration
    {
        /// <summary>
        /// This logs the kit in using Steam
        /// </summary>
        public class Kit_SteamLogin : Kit_MenuLogin
        {
            public override void BeginLogin()
            {
                if (Kit_SteamManager.Initialized)
                {
                    //Log in using Steam name and Steam ID
                    OnLoggedIn(SteamFriends.GetPersonaName(), SteamUser.GetSteamID().m_SteamID.ToString());
                }
            }
        }
    }
}
